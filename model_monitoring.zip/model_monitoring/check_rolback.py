import sys
import logging

from pyspark.sql import SparkSession
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient
from datetime import datetime, timedelta, timezone
import time
from pyspark.sql import SparkSession, functions as F
sys.path.insert(0, "/Workspace/application/demand_forecasting_spare_parts")

from src.model_registration.promotion_functions import _safe_get_alias, _safe_get_run
from src.config.drift_rollback_config import DEFAULT_ROLLBACK_THRESHOLDS, ROLLBACK_THRESHOLDS
from src.config.registry_config import REGISTRY_CONFIG
from src.utils.shared import parse_args, check_model_state, _is_in_settling_window
from src.utils.mailers import  send_degradation_alert, send_no_rollback_possible, send_no_champion_alert
from src.config.drift_rollback_config import AZURE_DEVOPS_PIPELINES, EMAIL_CONFIG


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
logger = logging.getLogger("check_rollback")

def _get_thresholds(config_dict: dict, model_key: str, default: dict) -> dict:
    """Return per-model threshold dict, falling back to default."""
    return config_dict.get(model_key, default)


def evaluate_degradation(
    client: MlflowClient,
    model_key: str,
    model_state: dict,
    profile_table: str
):
    """
    Compare the live Champion's monitoring MAE against its training-run MAE
    over multiple consecutive windows before flagging degradation.
 
    Returns:
        (is_degraded, consecutive_count, latest_monitoring_mae,
         champion_run_mae)
    """
    thresholds = _get_thresholds(
        ROLLBACK_THRESHOLDS, model_key, DEFAULT_ROLLBACK_THRESHOLDS
    )

    run_id = model_state.get("champion_run_id")
    if not run_id:
        return False, 0, None, None

    try:
        run = _safe_get_run(client, run_id)
        champion_run_mae = run.data.metrics.get("mae_next4w")
    except Exception as exc:
        return False, 0, None, None

    if champion_run_mae is None:
        return  False, 0, None, None

    required  = thresholds["consecutive_windows"]
    lookback  = required + 2

    try:
        rows = (
            spark.table(profile_table)
            .filter(
                (F.col("column_name") == ":table_name")
                & (F.col("metric_name") == "mean_absolute_error")
            )
            .orderBy(F.col("window_end_time").desc())
            .limit(lookback)
            .select("metric_value", "window_end_time")
            .collect()
        )
    except Exception as exc:
        return  False, 0, None, champion_run_mae

    if not rows:
        return False, 0, None, champion_run_mae

    latest_mae = float(rows[0]["metric_value"])
    # Count consecutive windows in breach, most recent first
    consecutive = 0
    for row in rows:
        mv  = float(row["metric_value"])
        pct = (mv - champion_run_mae) / champion_run_mae if champion_run_mae > 0 else 0
        if pct >= thresholds["mae_pct_increase"]:
            consecutive += 1
        else:
            break
    
    if consecutive>required:
        is_degraded = True
    else:
        is_degraded = False

    return is_degraded, consecutive, latest_mae, champion_run_mae

    
def run_rollback_detection(spark, catalog, schema, PROFILE_TABLE, CONTROL_TABLE):
    """
    Main entry point. Evaluates degradation for every model in REGISTRY_CONFIG,
    sends a human-approval email if degradation is confirmed.

    Args:
        Catalog, Schema of the registered model

    Returns:
        Dict mapping model_key → rollback detection result dict.
    """
    client   = MlflowClient()

    for model_key, config in REGISTRY_CONFIG.items():
        logger.info("=" * 70)
        logger.info("Rollback detection — model: %s", model_key)

        registered_model_name = f"{catalog}.{schema}.{config['model_name']}"
        thresholds = _get_thresholds(
            ROLLBACK_THRESHOLDS, model_key, DEFAULT_ROLLBACK_THRESHOLDS
        )

        try:
            
            model_state = check_model_state(client, registered_model_name, model_key)

            if not model_state["has_champion"]:
                logger.warning("No Champion for '%s' — skipping.", model_key)
                send_no_champion_alert(model_key, ado, cfg)
    
                continue

            if not model_state["has_challenger"]:
                logger.info(
                    "No Challenger for '%s' — degradation will be detected "
                    "but rollback.py will not be able to execute.",
                    model_key,
                )

           
            settling_hours = thresholds.get("settling_hours", 24)
            if _is_in_settling_window(spark, model_key, settling_hours, CONTROL_TABLE):

                continue

            
            is_degraded, consecutive, post_mae, champ_mae = evaluate_degradation(
                client=client,
                model_key=model_key,
                model_state=model_state,
                profile_table=PROFILE_TABLE
            )

            if not is_degraded:
                logger.info(
                    "Champion for '%s' is healthy — "
                    "live MAE=%.4f, training MAE=%.4f, consecutive_breach=%d.",
                    model_key,
                    post_mae or 0.0,
                    champ_mae or 0.0,
                    consecutive,
                )
                continue

            logger.warning(
                "Degradation confirmed for '%s' (%d consecutive windows)",
                model_key, consecutive   
            )

            # ── STEP 4: Alert — check whether rollback is even possible ────
            if not model_state["can_rollback"]:
                logger.error(
                    "Degradation detected for '%s' but no Challenger exists.",
                    model_key,
                )
                send_no_rollback_possible(model_key, registered_model_name, ado=ado,cfg=cfg)
                continue

            
            send_degradation_alert(
                model_key=model_key,
                registered_model_name=registered_model_name,
                model_state=model_state,
                consecutive_windows=consecutive,
                post_deploy_mae=post_mae,
                champion_run_mae=champ_mae,
                cfg=cfg,
                ado=ado
            )

        except Exception as exc:
            logger.error(
                "Unhandled error in rollback detection for '%s': %s",
                model_key, exc, exc_info=True,
            )

if __name__ == "__main__":
    #args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    #silver_catalog = f"{args.environment}_maintenance"
    #silver_schema = "silver_maintenance"
    #PROFILE_TABLE = f"{silver_catalog}.{silver_schema}.next4w_predictions_profile_metrics"
    #CONTROL_TABLE = f"{silver_catalog}.{silver_schema}.mlops_pipeline_control"
    cfg = EMAIL_CONFIG
    ado = AZURE_DEVOPS_PIPELINES
    time.sleep(100)
    #run_rollback_detection(spark,silver_catalog,silver_schema, PROFILE_TABLE, CONTROL_TABLE)

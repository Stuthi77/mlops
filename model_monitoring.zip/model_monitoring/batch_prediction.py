import sys
import os
import pandas as pd
import numpy as np
import logging

import mlflow
from mlflow.tracking import MlflowClient

from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import StructType, StructField, StringType, FloatType, DateType, TimestampType
from delta.tables import DeltaTable
from datetime import datetime, timedelta, date
from typing import Optional

sys.path.insert(0, "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting")
from src.utils.shared import parse_args, apply_segment_quantile_thresholds


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
log = logging.getLogger("next4w_batch_inference")


def load_champion_model(model_uri: str) -> tuple:
    """Load @Champion model; raises clearly if alias is missing."""
    mlflow.set_registry_uri("databricks-uc")
    client = MlflowClient()
    name, alias = model_uri.replace("models:/", "").rsplit("@", 1)
    try:
        mv = client.get_model_version_by_alias(name, alias)
    except Exception as e:
        raise RuntimeError(
            f"Could not resolve alias '{alias}' for model '{name}'. "
            f"Ensure a Champion alias is registered in Unity Catalog.\n{e}"
        )
    model = mlflow.pyfunc.load_model(model_uri)
    log.info(f"Loaded model '{name}' version {mv.version} (alias={alias})")
    return model, mv.version, name


def resolve_weeks_to_score(
    spark,
    feature_table: str,
    inference_table: str,
    baseline_table: str,
) -> list[date]:
    """
    Determine which week_start values in the feature store have not yet been
    scored in the inference table, filtering out anything within the baseline window.

    Baseline cutoff = MAX(week_start) from baseline table.
    Only weeks AFTER the baseline cutoff are eligible for inference.
    """
    feature_weeks_df = (
        spark.read.table(feature_table)
            .select("week")
            .distinct()
    )

    feature_count = feature_weeks_df.count()
    log.info(f"Feature store contains {feature_count} distinct week(s).")

    if feature_count == 0:
        log.warning("Feature store is empty — nothing to score.")
        return []

    # ── Baseline cutoff guard ─────────────────────────────────────────────────
    if spark.catalog.tableExists(baseline_table):
        baseline_max_row = (
            spark.read.table(baseline_table)
                .select(F.max("week").alias("max_week"))
                .collect()[0]
        )
        baseline_cutoff = baseline_max_row["max_week"]

        if baseline_cutoff is not None:
            log.info(
                "Baseline table found — max week_start: %s. "
                "Excluding all weeks <= this date from inference.",
                baseline_cutoff,
            )
            feature_weeks_df = feature_weeks_df.filter(
                F.col("week").cast("date") > F.to_date(F.lit(str(baseline_cutoff)))
            )
        else:
            log.warning("Baseline table exists but has no rows — no cutoff applied.")
    else:
        log.warning(
            "Baseline table '%s' not found — no cutoff applied. "
            "Ensure baseline is created before running inference.",
            baseline_table,
        )

    # ── Anti-join against already-scored weeks ────────────────────────────────
    if spark.catalog.tableExists(inference_table):
        scored_weeks_df = (
            spark.read.table(inference_table)
                .select(F.col("week").alias("week"))
                .distinct()
        )
        log.info("Inference table found — computing pending weeks via anti-join.")

        pending_df = (
            feature_weeks_df
                .join(scored_weeks_df, on="week", how="left_anti")
                .orderBy("week")
        )
    else:
        log.info("Inference table does not yet exist — all eligible weeks will be scored.")
        pending_df = feature_weeks_df.orderBy("week")

    pending = [row["week"] for row in pending_df.collect()]

    log.info(
        "Weeks pending inference: %d (%s → %s)",
        len(pending),
        pending[0] if pending else "n/a",
        pending[-1] if pending else "n/a",
    )
    return pending


def load_actuals(spark, actual_target_table: str) -> Optional[pd.DataFrame]:
    """
    Load the actual demand target table. Actuals arrive with a 4-week lag.
    Returns a DataFrame with at minimum:
        part_number, forecast_origin_week (datetime64), target_next_4_weeks

    Returns None if the table does not exist yet.
    """
    if not spark.catalog.tableExists(actual_target_table):
        log.warning(
            f"Target table '{actual_target_table}' does not exist yet — "
            "target_next_4_weeks will be NULL for all rows this run."
        )
        return None

    target_df = spark.read.table(actual_target_table).toPandas()
    target_df["week"] = pd.to_datetime(target_df["week"])
    log.info(
        f"Loaded actuals: {len(target_df)} rows, "
        f"weeks {target_df['week'].min().date()} → "
        f"{target_df['week'].max().date()}"
    )
    return target_df


def ensure_inference_table(spark, output_schema: StructType, inference_table: str) -> None:
    fields = ", ".join(f"`{f.name}` {f.dataType.simpleString()}" for f in output_schema.fields)
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {inference_table} ({fields})
        USING DELTA
        TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    """)
    log.info(f"Inference table ensured: '{inference_table}' (CDF enabled).")


def ensure_inference_table_from_features(
    spark,
    feature_table: str,
    inference_table: str,
    model_version: str,
    model_name: str,
) -> None:
    if spark.catalog.tableExists(inference_table):
        return

    sample_pd = (
        spark.read.table(feature_table)
        .limit(1)
        .toPandas()
    )

    if sample_pd.empty:
        log.warning(
            "Feature table '%s' has no rows — cannot derive schema for inference table.",
            feature_table,
        )
        return

    # Add all inference columns to the ONE-ROW sample
    sample_pd["forecast_origin_week"] = pd.to_datetime(sample_pd["week"])
    sample_pd["prediction_final"]     = np.float32(0.0)
    sample_pd["prediction_raw"]       = np.float32(0.0)
    sample_pd["model_version"]        = str(model_version)
    sample_pd["model_name"]           = str(model_name)
    sample_pd["prediction_timestamp"] = datetime.utcnow()

    # Infer schema from the one-row sample (has data → no ValueError)
    # then create an empty DataFrame using that schema explicitly
    schema = spark.createDataFrame(sample_pd).schema
    empty_spark = spark.createDataFrame([], schema=schema)  # ← explicit schema, no rows

    ensure_inference_table(spark, empty_spark.schema, inference_table)
    log.info("Inference table created (empty) — ready for monitor setup.")


def upsert_to_inference_table(
    spark,
    final_pd: pd.DataFrame,
    inference_table: str,
    merge_keys: tuple,
) -> None:
    assert len(merge_keys) > 0 and all(k in final_pd.columns for k in merge_keys), \
        f"merge_keys {merge_keys} must be non-empty and present in DataFrame columns"

    table_exists = spark.catalog.tableExists(inference_table)
    is_delta = (
        table_exists
        and spark.sql(f"DESCRIBE DETAIL {inference_table}").collect()[0]["format"] == "delta"
    )
    print(final_pd.dtypes)
    if is_delta:
        table_schema = DeltaTable.forName(spark, inference_table).toDF().schema
        print(table_schema)
        updates_df = spark.createDataFrame(final_pd, schema=table_schema)

        merge_condition = " AND ".join(f"target.{k} = source.{k}" for k in merge_keys)
        (
            DeltaTable.forName(spark, inference_table).alias("target")
            .merge(updates_df.alias("source"), merge_condition)
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
        log.info(f"Upsert complete → '{inference_table}'")
    else:
        if table_exists:
            log.warning(f"Table '{inference_table}' exists but is not Delta — overwriting.")
        else:
            log.info(f"Table '{inference_table}' does not exist — creating via overwrite.")

        updates_df = spark.createDataFrame(final_pd)
        (
            updates_df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .saveAsTable(inference_table)
        )
        log.info(f"Overwrite complete → '{inference_table}'")


def score_week(
    spark,
    week: date,
    model,
    model_version: str,
    model_name: str,
    actuals_df: Optional[pd.DataFrame],
    feature_table: str,
    x_segments: tuple,
    y_segments: tuple,
    x_target_nonzero_rate: float,
    y_target_nonzero_rate: float,
) -> pd.DataFrame:
    """
    Load features for a single week, run inference, apply segment quantile
    thresholds, join actuals, and return the final pandas DataFrame ready
    for upsert.
    """
    features_pd = (
        spark.read.table(feature_table)
        .filter(F.col("week").cast("date") == F.to_date(F.lit(str(week))))
        .toPandas()
    )
    row_count = len(features_pd)
    log.info(f"  Week {week}: {row_count} feature row(s) found.")

    if row_count == 0:
        log.warning(f"  Week {week}: no rows — skipping.")
        return pd.DataFrame()

    raw_preds = model.predict(features_pd)
    pred_df = (
        raw_preds if isinstance(raw_preds, pd.DataFrame)
        else pd.DataFrame({"prediction_raw": raw_preds})
    )
    if "prediction_raw" not in pred_df.columns:
        pred_df = pred_df.rename(columns={pred_df.columns[0]: "prediction_raw"})

    # pred_df["abc_xyz_segment"] = features_pd["abc_xyz_segment"].values
    # pred_df, _ = apply_segment_quantile_thresholds(
    #     pred_df,
    #     x_segments,
    #     y_segments,
    #     x_target_nonzero_rate,
    #     y_target_nonzero_rate,
    # )

    final_pd = features_pd.copy()
    final_pd["forecast_origin_week"] = pd.to_datetime(final_pd["week"])
    final_pd["prediction_final"]     = pred_df["prediction_raw"].values.astype(np.float32)
    final_pd["prediction_raw"]     = pred_df["prediction_raw"].values.astype(np.float32)
    final_pd["model_version"]        = str(model_version)
    final_pd["model_name"]           = model_name
    final_pd["prediction_timestamp"] = datetime.utcnow()

    if actuals_df is not None:
        final_pd = final_pd.merge(
            actuals_df[["product", "category","department", "country", "state", "target_qty"]],
            on=["product", "category","department", "country", "state"],
            how="left",
        )
        final_pd["target_qty"] = final_pd["target_qty"].astype(np.float32)
        matched = int(final_pd["target_qty"].notna().sum())
        log.info(
            f"  Week {week}: actuals joined — {matched}/{len(final_pd)} rows "
            f"have target_qty (expected 0 if lag < 4 weeks)."
        )
    else:
        final_pd["target_qty"] = np.full(len(final_pd), np.nan, dtype=np.float32)
        nonzero = int((final_pd["prediction_final"] > 0).sum())
        log.info(f"  Week {week}: scored {len(final_pd)} rows, {nonzero} non-zero predictions.")

    return final_pd


def run_batch_inference(spark, config: dict) -> None:
    log.info("START: next4w batch inference pipeline")

    FEATURE_TABLE         = config["feature_table"]
    INFERENCE_TABLE       = config["inference_table"]
    BASELINE_TABLE        = config["baseline_table"]
    ACTUAL_TARGET_TABLE   = config["actual_target_table"]
    MODEL_URI             = config["model_uri"]
    MERGE_KEYS            = config["merge_keys"]
    X_SEGMENTS            = config["x_segments"]
    Y_SEGMENTS            = config["y_segments"]
    X_TARGET_NONZERO_RATE = config["x_target_nonzero_rate"]
    Y_TARGET_NONZERO_RATE = config["y_target_nonzero_rate"]

    # ── Always ensure inference table exists (needed for monitor setup) ───────
    ensure_inference_table_from_features(
        spark,
        feature_table=FEATURE_TABLE,
        inference_table=INFERENCE_TABLE,
        model_version="unknown",
        model_name=MODEL_URI,
    )

    # ── Resolve pending weeks (baseline cutoff + anti-join) ───────────────────
    pending_weeks = resolve_weeks_to_score(
        spark,
        feature_table=FEATURE_TABLE,
        inference_table=INFERENCE_TABLE,
        baseline_table=BASELINE_TABLE,
    )
    if not pending_weeks:
        log.info("No pending weeks — inference table is up to date. Exiting.")
        return

    actuals_df = load_actuals(spark, ACTUAL_TARGET_TABLE)
    model, model_version, model_name = load_champion_model(MODEL_URI)

    table_initialised = False

    for week in pending_weeks:
        log.info(f"Scoring week: {week}")

        final_pd = score_week(
            spark=spark,
            week=week,
            model=model,
            model_version=model_version,
            model_name=model_name,
            actuals_df=actuals_df,
            feature_table=FEATURE_TABLE,
            x_segments=X_SEGMENTS,
            y_segments=Y_SEGMENTS,
            x_target_nonzero_rate=X_TARGET_NONZERO_RATE,
            y_target_nonzero_rate=Y_TARGET_NONZERO_RATE,
        )
        if final_pd.empty:
            continue

        # On the first non-empty result, update model_version/model_name
        # in the table if it was initialised with placeholder values
        if not table_initialised:
            table_initialised = True

        upsert_to_inference_table(spark, final_pd, INFERENCE_TABLE, MERGE_KEYS)

    log.info(
        "DONE: batch inference pipeline completed. %d week(s) processed.",
        len(pending_weeks),
    )


if __name__ == "__main__":
    spark = SparkSession.builder.getOrCreate()
    # args = parse_args()

    CATALOG = "ds_training_1"
    SCHEMA = "mlops_models"

    config = {
        "feature_table":          f"ds_training_1.mlops_featurestore.weekly_orders",
        "inference_table":        f"ds_training_1.mlops_inference_results.weekly_orders_predictions",
        "baseline_table":         f"ds_training_1.mlops_monitoringtables.weekly_orders_baseline",
        "actual_target_table":    f"ds_training_1.mlops_ground_truth_schema.weekly_orders_target",
        "model_uri":              f"models:/{CATALOG}.{SCHEMA}.weekly_demand_forecast_HPOv2@champion",
        "merge_keys":             ("product", "category","department", "country", "state"),
        "x_segments":             ("AX", "BX", "CX"),
        "y_segments":             ("AY", "BY", "CY"),
        "x_target_nonzero_rate":  0.99,
        "y_target_nonzero_rate":  0.85,
    }

    #run_batch_inference(spark, config)

# rollback.py
import sys
import logging
from datetime import datetime, timezone
from mlflow.tracking import MlflowClient
sys.path.insert(0, "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting")

from src.utils.shared import parse_args, check_model_state
from src.config.registry_config import REGISTRY_CONFIG


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
logger = logging.getLogger("rollback")


def _write_control_table(control_table: str, model_key: str, event_type: str):
    """
    Write a single event row to mlops_pipeline_control so that
    _is_in_settling_window() blocks the rollback/drift jobs for
    the configured settling period after this rollback completes.
    """
    now = datetime.now(timezone.utc)
    row = [(model_key, event_type, now)]

    (
        spark.createDataFrame(row, ["model_key", "event_type", "event_timestamp"])
        .write.format("delta")
        .mode("append")
        .saveAsTable(control_table)
    )
    logger.info(
        "Control table '%s' updated — model_key=%s, event_type=%s, ts=%s",
        control_table, model_key, event_type, now.isoformat(),
    )


def run_rollback():
    client = MlflowClient()
    args = parse_args()
    catalog = f"{args.environment}_maintenance"
    schema = "silver_maintenance"
    control_table = f"{catalog}.{schema}.mlops_pipeline_control"

    for model_key, config in REGISTRY_CONFIG.items():
        logger.info("=" * 60)
        logger.info("Running rollback for: %s", model_key)

        registered_model_name = f"{catalog}.{schema}.{config['model_name']}"

        
        model_state = check_model_state(client, registered_model_name, model_key)

        if not model_state["has_champion"]:
            logger.error("No Champion found for '%s' — cannot rollback.", model_key)
            continue

        if not model_state["can_rollback"]:
            logger.error("No Challenger found for '%s' — cannot rollback.", model_key)
            continue

        old_champion_version = model_state["champion_version"]
        new_champion_version = model_state["challenger_version"]

        logger.info(
            "Rolling back '%s': Champion v%s → Challenger v%s",
            model_key, old_champion_version, new_champion_version,
        )

       
        try:
            client.set_registered_model_alias(
                name=registered_model_name,
                alias="champion",
                version=new_champion_version,
            )
            client.delete_registered_model_alias(
                name=registered_model_name,
                alias="challenger",
            )
            logger.info(
                "Alias swap complete for '%s'. New Champion = v%s.",
                model_key, new_champion_version,
            )
        except Exception as exc:
            logger.error("MLflow alias update failed for '%s': %s", model_key, exc)
            continue

        
        try:
            _write_control_table(control_table, model_key, "rollback_complete")
        except Exception as exc:
            # Non-fatal — log but don't abort. The rollback itself succeeded.
            logger.warning(
                "Failed to write control table for '%s': %s — "
                "settling window will not be enforced for this rollback.",
                model_key, exc,
            )

if __name__ == "__main__":
    run_rollback()





import sys
import argparse
import time
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import (
    MonitorInferenceLog,
    MonitorInferenceLogProblemType,
    MonitorRefreshInfoState,
)
from databricks.sdk.errors import ResourceDoesNotExist
sys.path.insert(0, "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting")


w = WorkspaceClient()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--asset_dir", type=str, required=True)
    parser.add_argument("--environment", type=str, required=True)
    args, _ = parser.parse_known_args()
    return args

# args = parse_args()



# CATALOG         = f"{args.environment}_maintenance"
SCHEMA          = "silver_maintenance"
INFERENCE_TABLE = f"ds_training_1.mlops_inference_results.weekly_orders_predictions"
BASELINE_TABLE  = f"ds_training_1.mlops_monitoringtables.weekly_orders_baseline"
ASSETS_DIR      = "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting" #args.asset_dir

TIMESTAMP_COL  = "prediction_timestamp"
MODEL_ID_COL   = "model_version"
PREDICTION_COL = "prediction_final"
LABEL_COL      = "prediction_final"



def monitor_exists(table_name: str) -> bool:
    try:
        w.quality_monitors.get(table_name=table_name)
        return True
    except ResourceDoesNotExist:
        return False


def wait_for_refresh(table_name: str, refresh_id: str, poll_interval: int = 30) -> None:
    print(f"  Waiting for refresh {refresh_id}...")
    while True:
        refresh = w.quality_monitors.get_refresh(
            table_name=table_name,
            refresh_id=refresh_id,
        )
        state = refresh.state
        print(f"  State: {state}")
        if state in (
            MonitorRefreshInfoState.SUCCESS,
            MonitorRefreshInfoState.FAILED,
            MonitorRefreshInfoState.CANCELED,
        ):
            break
        time.sleep(poll_interval)

    if state != MonitorRefreshInfoState.SUCCESS:
        raise RuntimeError(f"Monitor refresh ended with state: {state}")
    print("  Refresh completed successfully.")


# ── Create or Refresh ─────────────────────────────────────────────────────────

if not monitor_exists(INFERENCE_TABLE):
    print(f"Creating monitor for: {INFERENCE_TABLE}")

    # monitor = w.quality_monitors.create(
    #     table_name=INFERENCE_TABLE,
    #     assets_dir=ASSETS_DIR,
    #     output_schema_name=f"ds_training_1.mlops_monitoringtables",
    #     inference_log=MonitorInferenceLog(
    #         problem_type=MonitorInferenceLogProblemType.PROBLEM_TYPE_REGRESSION,
    #         prediction_col=PREDICTION_COL,
    #         model_id_col=MODEL_ID_COL,
    #         label_col=LABEL_COL,
    #         timestamp_col=TIMESTAMP_COL,
    #         granularities=["4 weeks"],
    #     ),
    #     baseline_table_name=BASELINE_TABLE
    # )

    # print(f"  Status      : {monitor.status}")
    # print(f"  Dashboard ID: {monitor.dashboard_id}")

else:
    # print(f"Monitor exists — triggering refresh for: {INFERENCE_TABLE}")
    #refresh = w.quality_monitors.run_refresh(table_name=INFERENCE_TABLE)
    #wait_for_refresh(INFERENCE_TABLE, refresh.refresh_id)
    pass

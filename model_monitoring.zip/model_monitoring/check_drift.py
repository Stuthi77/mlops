import sys
import os
import logging
import time
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient
from pyspark.sql import SparkSession, functions as F
from pyspark.sql import DataFrame

sys.path.insert(0, "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting")

from src.utils.shared import parse_args, check_model_state, _is_in_settling_window
from src.config.registry_config import REGISTRY_CONFIG
from src.config.drift_rollback_config import AZURE_DEVOPS_PIPELINES, EMAIL_CONFIG
from src.utils.mailers import send_drift_alert, send_no_champion_alert, send_no_challenger_alert
from src.model_registration.model_registration import _build_model_name

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
logger = logging.getLogger("check_drift")

def detect_drift(
    DRIFT_TABLE: str,
    EXCLUDE_COLUMNS,

) -> dict:
    """
    Detect drift from lakehouse monitoring table and send alert if needed.

    Returns:
        dict with drift_detected flag and drifted_columns list
    """
    df = (
        spark.table(DRIFT_TABLE)
        .select("window", "column_name", "data_type", "ks_test", "chi_squared_test")
        .filter(~F.col("column_name").isin(EXCLUDE_COLUMNS))
    )

    df = df.withColumn("window_end", F.col("window.end"))
    df = (df.withColumn("ks_pvalue", F.col("ks_test.pvalue")).withColumn("chi_pvalue", F.col("chi_squared_test.pvalue")))
    if df.count() > 0:
        latest = df.select("window_end").orderBy(F.col("window_end").desc()).limit(1).collect()[0][0]
        df = df.filter(F.col("window_end") == latest)
        df = df.dropDuplicates()
        df = df.withColumn(
            "is_drift",
            (
                (F.col("ks_pvalue") < 0.05) |
                (F.col("chi_pvalue") < 0.05)
            )
        )
        drifted_cols = (
            df.filter(F.col("is_drift"))
            .select("column_name")
            .distinct()
        )

        drifted_list = [row["column_name"] for row in drifted_cols.collect()]
        drift_count = len(drifted_list)

        drift_detected = drift_count > 4

        if drift_detected:
            return {
            "drift_detected": drift_detected,
            "drifted_columns": drifted_list,
            "drift_count": drift_count
            }
        else:
            return None
    else:
        return None
    
def run_pipeline(spark, DRIFT_TABLE, EXCLUDE_COLUMNS, CATALOG, SCHEMA, CONTROL_TABLE):
    client   = MlflowClient()
    drift =  detect_drift(DRIFT_TABLE,EXCLUDE_COLUMNS)
    if drift is not None:
        for model_key, config in REGISTRY_CONFIG.items():
            registered_model_name = _build_model_name(
                CATALOG,
                SCHEMA,
                config["model_name"],
            )
            try:
                model_state = check_model_state(client, registered_model_name, model_key)
                if not model_state["has_champion"]:
                    send_no_champion_alert(model_key, ado, cfg)
                    continue

                if not model_state["has_challenger"]:
                    send_no_challenger_alert(model_key, ado, cfg)
                    continue 

                settling_hours = 4
                if _is_in_settling_window(spark, model_key, settling_hours, CONTROL_TABLE):
                    continue

                send_drift_alert(registered_model_name, drift, model_state, ado, cfg)
            except Exception as exc:
                logger.error(
                    "Unhandled error in rollback detection for '%s': %s",
                    model_key, exc, exc_info=True,
                )

if __name__ == "__main__":
    cfg = EMAIL_CONFIG
    ado = AZURE_DEVOPS_PIPELINES

    #args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    time.sleep(200)
    #CATALOG = f"{args.environment}_maintenance"
    #SCHEMA  = "silver_maintenance"
    #CONTROL_TABLE = f"{CATALOG}.{SCHEMA}.mlops_pipeline_control"
    #DRIFT_TABLE =  f"{CATALOG}.{SCHEMA}.next4w_predictions_drift_metrics"

    EXCLUDE_COLUMNS = [
        ":table", "abc_xyz_segment", "part_number", "account",
        "model_name", "category_code",
        "prediction_timestamp", "forecast_origin_week",
        "prediction_final", 
    ]
    
    #run_pipeline(spark,DRIFT_TABLE, EXCLUDE_COLUMNS, CATALOG, SCHEMA, CONTROL_TABLE)

# Databricks notebook source
# MAGIC %pip install databricks-feature-store
# MAGIC %restart_python

# COMMAND ----------

import pandas as pd
import numpy as np
from databricks.feature_store import FeatureStoreClient
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

df = spark.read.table("ds_training_1.mlops_dataset.dataco").toPandas()
df["order_date"] = pd.to_datetime(df["order_date"])
df = df[df["order_date"]<pd.to_datetime("2017-01-01")]

# COMMAND ----------

weekly = (
    df.groupby(
        [
            pd.Grouper(
                key="order_date",
                freq="W-MON"
            ),
            "product",
            "category",
            "department",
            "country",
            "state"
        ]
    )
    .agg(
        target_qty=("order_qty", "sum"),
        avg_price=("unit_price", "mean"),
        min_price=("unit_price", "min"),
        max_price=("unit_price", "max"),
        std_price=("unit_price", "std"),
        total_orders=("order_id", "count"),
        unique_customers=("customer_id", "nunique"),
        avg_order_qty=("order_qty", "mean"),
        total_sales=("sales", "sum"),
        avg_sched_ship=("sched_ship_days", "mean"),
        avg_actual_ship=("actual_ship_days", "mean"),
        late_rate=("late_risk", "mean"),
        consumer_orders=(
            "cust_segment",
            lambda x: (x == "Consumer").sum()
        ),
        corporate_orders=(
            "cust_segment",
            lambda x: (x == "Corporate").sum()
        ),
        home_office_orders=(
            "cust_segment",
            lambda x: (x == "Home Office").sum()
        )
    )
    .reset_index()
)

weekly.rename(
    columns={
        "order_date": "week"
    },
    inplace=True
)

weekly["consumer_pct"] = (
    weekly["consumer_orders"] /
    weekly["total_orders"]
)
weekly["corporate_pct"] = (
    weekly["corporate_orders"] /
    weekly["total_orders"]
)
weekly["home_office_pct"] = (
    weekly["home_office_orders"] /
    weekly["total_orders"]
)
weekly.drop(
    columns=[
        "consumer_orders",
        "corporate_orders",
        "home_office_orders"
    ],
    inplace=True
)

weekly["year"] = weekly["week"].dt.year
weekly["month"] = weekly["week"].dt.month
weekly["quarter"] = weekly["week"].dt.quarter

weekly["week_of_year"] = (
    weekly["week"]
    .dt.isocalendar()
    .week
    .astype(int)
)

weekly["week_of_month"] = (
    (weekly["week"].dt.day - 1) // 7 + 1
)

weekly["month_start"] = (
    weekly["week"].dt.is_month_start.astype(int)
)

weekly["month_end"] = (
    weekly["week"].dt.is_month_end.astype(int)
)

weekly["quarter_start"] = (
    weekly["week"].dt.is_quarter_start.astype(int)
)

weekly["quarter_end"] = (
    weekly["week"].dt.is_quarter_end.astype(int)
)

weekly["year_start"] = (
    weekly["week"].dt.is_year_start.astype(int)
)

weekly["year_end"] = (
    weekly["week"].dt.is_year_end.astype(int)
)

weekly["days_from_start"] = (
    weekly["week"] - weekly["week"].min()
).dt.days

group_cols = [
    "product",
    "country",
    "state"
]


lags = [1, 2, 3, 4, 8, 12]

for lag in lags:

    weekly[f"lag_{lag}"] = (
        weekly
        .groupby(group_cols)["target_qty"]
        .shift(lag)
    )

weekly["rolling_mean_4"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(4).mean()
    )
)

weekly["rolling_mean_8"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(8).mean()
    )
)

weekly["rolling_std_4"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(4).std()
    )
)

weekly["rolling_std_8"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(8).std()
    )
)

weekly["rolling_min_4"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(4).min()
    )
)

weekly["rolling_max_4"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).rolling(4).max()
    )
)

weekly["ewm_4"] = (
    weekly.groupby(group_cols)["target_qty"]
    .transform(
        lambda x: x.shift(1).ewm(span=4).mean()
    )
)


weekly["price_change"] = (
    weekly.groupby(group_cols)["avg_price"]
    .pct_change()
)

weekly["price_lag1"] = (
    weekly.groupby(group_cols)["avg_price"]
    .shift(1)
)


weekly["orders_lag1"] = (
    weekly.groupby(group_cols)["total_orders"]
    .shift(1)
)

weekly["customers_lag1"] = (
    weekly.groupby(group_cols)["unique_customers"]
    .shift(1)
)

weekly["sales_lag1"] = (
    weekly.groupby(group_cols)["total_sales"]
    .shift(1)
)


weekly = weekly.sort_values(
    group_cols + ["week"]
)
weekly = weekly.dropna().reset_index(drop=True)
print(weekly.head())
print(weekly.shape)

# COMMAND ----------

target = weekly[["week", "product", "category", "department", "country", "state", "target_qty"]]
target_spark = spark.createDataFrame(target)
table_name = "ds_training_1.mlops_ground_truth_schema.weekly_orders_target"
try:
    spark.table(table_name)
    (
        target_spark.mergeInto(
            table_name,
            (
                (target_spark.week == spark.table(table_name).week) &
                (target_spark.product == spark.table(table_name).product) &
                (target_spark.category == spark.table(table_name).category) &
                (target_spark.department == spark.table(table_name).department) &
                (target_spark.country == spark.table(table_name).country) &
                (target_spark.state == spark.table(table_name).state)
            )
        )
        .whenMatched().updateAll()
        .whenNotMatched().insertAll()
        .merge()
    )
except AnalysisException:
    target_spark.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

fs = FeatureStoreClient()
weekly.drop("target_qty", inplace=True,axis=1)
feature_table_name = "ds_training_1.mlops_featurestore.="
weekly_spark = spark.createDataFrame(weekly)

try:
    fs.get_table(feature_table_name)
    table_exists = True
except:
    table_exists = False

if not table_exists:

    fs.create_table(
        name=feature_table_name,
        primary_keys=["product", "country", "state", "week"],
        df=weekly_spark,
        description="Weekly features for product-country-state combinations"
    )
else:
    fs.write_table(
        name=feature_table_name,
        df=weekly_spark,
        mode="merge"
    )

# COMMAND ----------


"""
Helper functions used in different parts of the ML lifecycle.
"""
import numpy as np
import pandas as pd
from delta.tables import DeltaTable
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from mlflow.exceptions import MlflowException
from mlflow.tracking import MlflowClient
from datetime import datetime, timezone, timedelta
from pyspark.sql import SparkSession, functions as F
import functools
import time
import argparse


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
logger = logging.getLogger("mailers")

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--environment", type=str, required=True)
    args, _ = parser.parse_known_args()
    return args

def upsert_to_target_table(spark, updates_df, TARGET_TABLE, MERGE_KEYS) -> None:
    """MERGE predictions into the Delta inference table; creates it on first run."""
    merge_condition = " AND ".join(
        [f"target.{col} = source.{col}" for col in MERGE_KEYS]
    )

    if not spark.catalog.tableExists(TARGET_TABLE):
        updates_df.limit(0).write \
            .format("delta") \
            .mode("overwrite") \
            .option("overwriteSchema", "true") \
            .saveAsTable(TARGET_TABLE)

    (
        DeltaTable.forName(spark, TARGET_TABLE).alias("target")
        .merge(updates_df.alias("source"), merge_condition)
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )

def apply_segment_quantile_thresholds(df_pred: pd.DataFrame, X_SEGMENTS, Y_SEGMENTS, X_TARGET_NONZERO_RATE, Y_TARGET_NONZERO_RATE) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Zero-out low predictions per ABC-XYZ segment bucket via quantile threshold.
    Returns (df_with_prediction_final, threshold_audit_df).
    """
    df = df_pred.copy()
    df["prediction_raw"]   = pd.to_numeric(df["prediction_raw"], errors="coerce").fillna(0.0)
    df["prediction_final"] = df["prediction_raw"].copy()

    threshold_rows = []

    for segments, label, rate in [
        (X_SEGMENTS, "X_SEGMENTS", X_TARGET_NONZERO_RATE),
        (Y_SEGMENTS, "Y_SEGMENTS", Y_TARGET_NONZERO_RATE),
    ]:
        mask = df["abc_xyz_segment"].isin(segments)
        n = int(mask.sum())
        if n == 0:
            continue

        threshold = float(np.quantile(df.loc[mask, "prediction_raw"], 1 - rate))
        df.loc[mask, "prediction_final"] = np.where(
            df.loc[mask, "prediction_raw"] >= threshold,
            df.loc[mask, "prediction_raw"],
            0.0,
        )
        threshold_rows.append({
            "segment_bucket":           label,
            "target_pred_nonzero_rate": rate,
            "applied_threshold":        threshold,
            "n_rows":                   n,
        })
    return df, pd.DataFrame(threshold_rows)


# ---------------------------------------------------------------------------
# Pre-flight: Champion / Challenger alias state check
# ---------------------------------------------------------------------------
def check_model_state(
    client: MlflowClient,
    registered_model_name: str,
    model_key: str,
) -> dict:
    from src.model_registration.promotion_functions import _safe_get_alias
    """
    Query Unity Catalog for the current Champion and Challenger aliases.
 
    Returns a dict with keys:
        has_champion        bool
        has_challenger      bool
        champion_version    str | None
        challenger_version  str | None
        champion_run_id     str | None
        can_rollback        bool   — True only when BOTH aliases exist
    """
    state = {
        "has_champion":       False,
        "has_challenger":     False,
        "champion_version":   None,
        "challenger_version": None,
        "champion_run_id":    None,
        "can_rollback":       False,
    }
    
    try:
        champion = _safe_get_alias(client, registered_model_name, "champion")
        state["has_champion"]     = True
        state["champion_version"] = champion.version
        state["champion_run_id"]  = champion.run_id
    except MlflowException:
        logger.warning(
            "Pre-flight [%s]: No 'champion' alias on '%s'.",
            model_key, registered_model_name,
        )
 
    try:
        challenger = _safe_get_alias(client, registered_model_name, "challenger")
        state["has_challenger"]     = True
        state["challenger_version"] = challenger.version
        logger.info(
            "Pre-flight [%s]: Challenger — version %s", model_key, challenger.version
        )
    except MlflowException:
        logger.info(
            "Pre-flight [%s]: No 'challenger' alias — rollback not possible.", model_key
        )
 
    state["can_rollback"] = state["has_champion"] and state["has_challenger"]
    return state


def _is_in_settling_window(spark,
    model_key: str, settling_hours: int, CONTROL_TABLE: str
) -> bool:
    """
    Return True if a retrain_complete or drift_detected event for model_key
    exists in the control table within the last `settling_hours` hours.

    Purpose: suppress rollback evaluation immediately after a retrain so
    the monitoring table has time to accumulate meaningful inference windows
    before we compare the new Champion's live MAE against its training MAE.
    """
    try:
        cutoff = (
            datetime.now(timezone.utc) - timedelta(weeks=settling_hours)
        ).strftime("%Y-%m-%d %H:%M:%S UTC")

        rows = (
            spark.table(CONTROL_TABLE)
            .filter(
                (F.col("model_key") == model_key)
                & (F.col("event").isin("retrain_complete", "drift_detected"))
                & (F.col("registered_at") >= cutoff)
            )
            .limit(1)
            .collect()
        )
        if rows:
            logger.info(
                "Settling window active for '%s' (event within %dh) — "
                "skipping rollback evaluation.",
                model_key, settling_hours,
            )
            return True
        return False
    except Exception as exc:
        # Control table may not exist on first run — proceed without suppression
        logger.warning(
            "Could not read control table for '%s': %s — proceeding.", model_key, exc
        )
        return False
    
def _retry(max_attempts: int = 3, base_delay: float = 2.0):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except MlflowException as exc:
                    last_exc = exc
                    wait = base_delay ** attempt
                    logger.warning(
                        "MLflow call '%s' failed (attempt %d/%d): %s — retrying in %.1fs",
                        func.__name__, attempt, max_attempts, exc, wait,
                    )
                    time.sleep(wait)
            raise RuntimeError(
                f"MLflow call '{func.__name__}' failed after {max_attempts} attempts"
            ) from last_exc
        return wrapper
    return decorator
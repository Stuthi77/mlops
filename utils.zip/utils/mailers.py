"""
mailers.py
----------
Each function builds an HTML body, constructs an EmailMessage, and sends
it via SMTP
 
Functions
---------
    send_smtp(subject, html_body, cfg)
        Core send — called by every mailer below.
 
    send_drift_alert(model_key, registered_model_name, signal, model_state)
        Drift detected on Champion. Human must approve retraining.
 
    send_degradation_alert(model_key, registered_model_name, model_state,
                           degradation_reasons, consecutive_windows,
                           post_deploy_mae, champion_run_ma)
        Champion degraded for N consecutive windows. Human must approve rollback.
 
    send_no_champion_alert(model_key)
        No Champion alias found — pipeline cannot proceed.
 
    send_no_rollback_possible(model_key, registered_model_name)
        Degradation confirmed but no Challenger exists to roll back to.

"""

import sys
import os
from email.message import EmailMessage
import logging
import smtplib

sys.path.insert(0, "/Workspace/Users/abhishek.iyer@latentviewo365.onmicrosoft.com/demand_forecasting")
from src.config.drift_rollback_config import AZURE_DEVOPS_PIPELINES, EMAIL_CONFIG



logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s"
)
logger = logging.getLogger("Mailing")
cfg = EMAIL_CONFIG
ado = AZURE_DEVOPS_PIPELINES

def send_smtp(subject, html_body, cfg) -> bool:
    """
    Build an EmailMessage and send via SMTP.
 
    Matches the confirmed working anonymous relay pattern:
        msg = EmailMessage()
        msg.set_content(plaintext_fallback)
        msg.add_alternative(html_body, subtype="html")
        smtp.send_message(msg)
 
    Args:
        subject   : Email subject line.
        html_body : Full HTML string for the email body.
 
    Returns:
        True if sent successfully, False on SMTP error.
    """
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"]    = cfg["sender"]
    msg["To"]      = ", ".join(cfg["recipients"])
    msg.set_content("This alert requires an HTML-capable email client.")
    msg.add_alternative(html_body, subtype="html")

    try:
        with smtplib.SMTP(cfg["SMTP_HOST"],cfg["SMTP_PORT"],) as smtp:
            smtp.send_message(msg)
        logger.info("Email sent: '%s' → %s", subject[:70], cfg["recipients"])
        return True
    except smtplib.SMTPException as exc:
        logger.error("SMTP error: %s", exc)
        return False
    
def send_drift_alert(
    registered_model_name: str,
    signal: dict,
    model_state: dict,
    cfg: dict,
    ado: dict
) -> bool:
    """
    Notify the team that input drift has been detected on the Champion model.
    No automatic action is taken — human must click the retraining button.
 
    Args:
        registered_model_name : Fully-qualified Unity Catalog model name.
        signal                : Drift signal dict from evaluate_drift().
        model_state           : Alias state dict from check_model_state().
    """
    subject = f" Demand Forecasting Spare parts - Drift detected — human approval required"
 
    body = f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:700px;margin:0 auto;">
 
    <h2 style="color:#e67e22;border-bottom:2px solid #e67e22;padding-bottom:8px;">
      ⚠️ Input Drift Detected
    </h2>
    <p>The Lakehouse Monitoring pipeline has detected input drift on the current
       Champion model. <b>No automatic action has been taken.</b><br/>
       Please review the statistics below and approve retraining if appropriate.</p>
 
    <h3 style="margin-top:20px;">Model State</h3>
    <table border="1" cellpadding="6" cellspacing="0"
           style="border-collapse:collapse;width:100%;margin-bottom:14px;">
      <tr style="background:#f5f5f5;">
        <th style="text-align:left;">Field</th>
        <th style="text-align:left;">Value</th>
      </tr>
      <tr><td><b>Registered Model</b></td><td>{registered_model_name}</td></tr>
      <tr><td><b>Champion Version</b></td>
          <td>{model_state.get("champion_version", "N/A")}</td></tr>
      <tr><td><b>Champion Run ID</b></td>
          <td>{model_state.get("champion_run_id", "N/A")}</td></tr>
      <tr><td><b>Challenger Version</b></td>
          <td>{model_state.get("challenger_version", "N/A (no challenger)")}</td></tr>
      <tr><td><b>Drift Count</b></td>
          <td>{signal.get("drift_count", 0)}</td>
      </tr>
      <tr><td><b>Drifted Columns</b></td>
        <td>{", ".join(signal.get("drifted_columns", [])) or "None"}</td>
      </tr>
    </table>
 
 
    <h3>Action Required</h3>
    <p>Click below to trigger the retraining pipeline in Azure DevOps:</p>
    <p>
      <a href="{ado['retrain_pipeline_url']}"
         style="background:#0078d4;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;font-weight:bold;">
        ▶ Trigger Retraining Pipeline
      </a>
      &nbsp;&nbsp;
      <a href="{ado['rollback_pipeline_url']}"
         style="background:#6c757d;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;">
        ↩ Trigger Rollback Pipeline (if preferred)
      </a>
    </p>
 
    <p style="color:#999;font-size:11px;margin-top:24px;">
      This is an automated alert. No pipeline has been triggered automatically.<br/>
    </p>
    </body></html>
    """
    return send_smtp(subject, body, cfg)


# ---------------------------------------------------------------------------
# Degradation alert
# Sent by: rollback_detection.py when Champion degrades for N consecutive windows
# Human action: click "Trigger Rollback Pipeline"
# ---------------------------------------------------------------------------
def send_degradation_alert(
    model_key: str,
    registered_model_name: str,
    model_state: dict,
    ado: dict,
    consecutive_windows: int,
    cfg: dict,
    post_deploy_mae,
    champion_run_mae
) -> bool:
    """
    Notify the team that the Champion has degraded for N consecutive monitoring
    windows. No automatic rollback is taken — human must click the rollback button.
 
    Args:
        model_key             : Key from REGISTRY_CONFIG.
        registered_model_name : Fully-qualified Unity Catalog model name.
        model_state           : Alias state dict from check_model_state().
        degradation_reasons   : List of human-readable reason strings.
        consecutive_windows   : Number of consecutive windows in breach.
        post_deploy_mae       : Latest monitoring window MAE.
        champion_run_mae      : Champion's training-run MAE from MLflow.
    """
    subject = (
        f"Model degradation detected — human approval required"
    )
 
    pct_str = "N/A"
    if post_deploy_mae is not None and champion_run_mae and champion_run_mae > 0:
        pct = (post_deploy_mae - champion_run_mae) / champion_run_mae * 100
        pct_str = f"{pct:+.1f}%"
 
    rollback_target = (
        f"Version {model_state['challenger_version']}"
        if model_state.get("challenger_version") else "No challenger registered"
    )
 
    body = f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:700px;margin:0 auto;">
 
    <h2 style="color:#c0392b;border-bottom:2px solid #c0392b;padding-bottom:8px;">
      Champion Model Degradation Detected — {model_key}
    </h2>
    <p>The Champion model has shown sustained degradation across
       <b>{consecutive_windows} consecutive monitoring windows</b>.
       <b>No automatic rollback has been executed.</b><br/>
       Please review the statistics below and approve a rollback if appropriate.</p>
 
    <h3 style="margin-top:20px;">Degradation Summary</h3>
    <table border="1" cellpadding="6" cellspacing="0"
           style="border-collapse:collapse;width:100%;margin-bottom:14px;">
      <tr style="background:#f5f5f5;">
        <th style="text-align:left;">Field</th>
        <th style="text-align:left;">Value</th>
      </tr>
      <tr><td><b>Registered Model</b></td><td>{registered_model_name}</td></tr>
      <tr><td><b>Current Champion Version</b></td>
          <td>{model_state.get("champion_version", "N/A")}</td></tr>
      <tr><td><b>Champion Run ID</b></td>
          <td>{model_state.get("champion_run_id", "N/A")}</td></tr>
      <tr><td><b>Rollback Target (Challenger)</b></td>
          <td><b>{rollback_target}</b></td></tr>
      <tr><td><b>Champion Training MAE</b></td>
          <td>{f"{champion_run_mae:.4f}" if champion_run_mae else "N/A"}</td></tr>
      <tr><td><b>Latest Monitoring MAE</b></td>
          <td>{f"{post_deploy_mae:.4f}" if post_deploy_mae else "N/A"}</td></tr>
      <tr><td><b>MAE Degradation vs Training</b></td>
          <td style="color:#c0392b;font-weight:bold;">{pct_str}</td></tr>
      <tr><td><b>Consecutive Degraded Windows</b></td>
          <td style="color:#c0392b;font-weight:bold;">{consecutive_windows}</td></tr>
    </table>
 
    <h3>Action Required</h3>
    <p>Click below to trigger the rollback pipeline in Azure DevOps:</p>
    <p>
      <a href="{ado['rollback_pipeline_url']}"
         style="background:#c0392b;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;font-weight:bold;">
        ↩ Trigger Rollback Pipeline
      </a>
      &nbsp;&nbsp;
      <a href="{ado['retrain_pipeline_url']}"
         style="background:#6c757d;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;">
        ▶ Trigger Retraining Instead
      </a>
    </p>

    </body></html>
    """
    return send_smtp(subject, body, cfg)


def send_no_rollback_possible(
    model_key: str,
    registered_model_name: str,
    ado: dict, 
    cfg: dict
) -> bool:
    """
    Notify that the Champion is degrading but there is no Challenger to roll
    back to. Requires manual intervention.
 
    Args:
        model_key             : Key from REGISTRY_CONFIG.
        registered_model_name : Fully-qualified Unity Catalog model name.
    """
    subject = (
        f" Degradation detected, no rollback possible — {model_key}"
    )
 
    body = f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:680px;margin:0 auto;">
    <h2 style="color:#c0392b;border-bottom:2px solid #c0392b;padding-bottom:8px;">
        Degradation Detected — No Challenger Available
    </h2>
    <p><b>Model key:</b> {model_key}<br/>
       <b>Registered name:</b> {registered_model_name}</p>
    <p>The rollback detection pipeline confirmed the Champion is degrading,
       but there is no <b>Challenger</b> alias in the registry to roll back to.</p>
    <p><b>Manual action required.</b> Either promote a previous version
       manually in Unity Catalog, or trigger a fresh retrain.</p>
    <p>
      <a href="{ado['retrain_pipeline_url']}"
         style="background:#0078d4;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;">
        ▶ Trigger Retraining Pipeline
      </a>
    </p>
    </body></html>
    """
    return send_smtp(subject, body, cfg)

def send_no_champion_alert(model_key: str, ado: dict, cfg:dict) -> bool:
    """
    Notify that no Champion alias exists in the registry.
    Neither pipeline can proceed without a Champion.
 
    Args:
        model_key : Key from REGISTRY_CONFIG.
    """
    subject = f"No champion model registered — {model_key}"
 
    body = f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:680px;margin:0 auto;">
    <h2 style="color:#cc6600;border-bottom:2px solid #cc6600;padding-bottom:8px;">
      ⚠️ No Champion Model Registered — {model_key}
    </h2>
    <p>The MLOps pipeline could not proceed because no <b>Champion</b> alias
       was found in the Unity Catalog model registry.</p>
    <p>Please run the scheduled training pipeline first, or manually assign
       a Champion alias in Unity Catalog.</p>
    <p>
      <a href="{ado['retrain_pipeline_url']}"
         style="background:#0078d4;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;">
        ▶ Trigger Retraining Pipeline
      </a>
    </p>
    </body></html>
    """
    return send_smtp(subject, body, cfg)

def send_no_challenger_alert(model_key: str, ado: dict, cfg:dict) -> bool:
    """
    Notify that no Challenger alias exists in the registry.
    Neither pipeline can proceed without a Challenger.
 
    Args:
        model_key : Key from REGISTRY_CONFIG.
    """
    subject = f"No Challenger model registered — {model_key}"
 
    body = f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:680px;margin:0 auto;">
    <h2 style="color:#cc6600;border-bottom:2px solid #cc6600;padding-bottom:8px;">
      ⚠️ No Challenger Model Registered — {model_key}
    </h2>
    <p>The MLOps pipeline could not proceed because no <b>Challenger</b> alias
       was found in the Unity Catalog model registry.</p>
    <p>Please run the scheduled training pipeline first, or manually assign
       a Challenger alias in Unity Catalog.</p>
    <p>
      <a href="{ado['retrain_pipeline_url']}"
         style="background:#0078d4;color:white;padding:10px 22px;border-radius:4px;
                text-decoration:none;display:inline-block;">
        ▶ Trigger Retraining Pipeline
      </a>
    </p>
    </body></html>
    """
    return send_smtp(subject, body, cfg)
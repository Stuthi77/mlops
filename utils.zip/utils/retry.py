import functools
import time
from typing import Optional

from mlflow.exceptions import MlflowException

def _retry(max_attempts: int = 3, base_delay: float = 2.0):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except MlflowException as exc:
                    last_exc = exc
                    wait = base_delay ** attempt
                    time.sleep(wait)
            raise RuntimeError(
                f"MLflow call '{func.__name__}' failed after {max_attempts} attempts"
            ) from last_exc
        return wrapper
    return decorator